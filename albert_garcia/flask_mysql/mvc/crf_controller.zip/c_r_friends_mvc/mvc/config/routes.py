# routes
from mvc import app
from mvc.controllers.friends import Friends
from mvc.controllers.friends import Add
from mvc.config.mysqlconnection import connectToMySQL
friends = Friends()

@app.route('/')
def Index():
    return friends.Index()

@app.route('/add', methods = ['POST'])
def Add():
    return friends.Add()