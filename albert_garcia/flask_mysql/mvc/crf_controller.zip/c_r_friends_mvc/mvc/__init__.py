# __init__file
from flask import Flask, render_template, request, redirect, session, flash
app = Flask(__name__)
app.secret_key = 'keep it secret, keep it safe'