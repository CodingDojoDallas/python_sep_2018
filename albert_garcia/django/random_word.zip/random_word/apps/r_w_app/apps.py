from django.apps import AppConfig


class RWAppConfig(AppConfig):
    name = 'r_w_app'
