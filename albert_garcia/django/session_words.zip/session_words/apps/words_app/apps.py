from django.apps import AppConfig


class WordsAppConfig(AppConfig):
    name = 'words_app'
